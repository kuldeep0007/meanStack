var exp=require('express');
var view=exp();

view.set("view engine","jade");

view.get("/jade",function(req,res){
    res.render("hello");
});

view.listen(3001,()=>{
    console.log("Jade running");
})