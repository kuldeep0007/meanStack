// var add= require('./lib/add');
// var products= require('./lib/product');

// console.log("welcome to node");
// add.addData();
// add.getData();

// var p1= new products.product("kdgs","rtyr",23412);
// var p2= new products.product("fb","dfgh",63);
// var p3= new products.product("sdg","dfbd",345);

// products.addproduct(p1);
// products.addproduct(p2);
// products.addproduct(p3);

// products.printProduct();

var add = require('./lib/add');
var products = require('./lib/product');

console.log("welcome to node");
add.addData();
add.getData();

var p1 = new products.prod("kdgs", "rtyr", 23412);
var p2 = new products.prod("fb", "dfgh", 63);
var p3 = new products.prod("sdg", "dfbd", 345);

products.set(p1);
products.set(p2);
products.set(p3);
products.display();

console.log("--------------------------------------------------------");


var buffer = new Buffer(18);
buffer.write("kuldeep");
console.log(buffer);
console.log(buffer.toString())



console.log("--------------------------------------------------------");




// ***************************Event in Node****************************
var event = require('events');//core module of node
var myevent = new event.EventEmitter();//creating object of eventEmitter
//registring an event
myevent.on("abc", function (msg) {
    console.log("In event abc---"+msg.name +"--"+msg.salary);
    setTimeout(()=>{console.log("after timeout of 6 sec")},10000);
//    setTimeout(function(){
//        console.log("after timeout of 6 sec");
//    },600);
});


myevent.on("xyz", function (msg) {
    console.log(msg);
});
//event emmition or event calling 
myevent.emit("abc", { name: "kuldeep", salary: 30000 });
myevent.emit("xyz", "In xyz event");