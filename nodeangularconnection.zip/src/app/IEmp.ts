export interface IEmp{
    _id:string;
    name:string;
    age:number;
}