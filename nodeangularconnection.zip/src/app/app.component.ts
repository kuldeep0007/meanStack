import { Component } from '@angular/core';
import {ServiceCallerService  } from '../service-caller.service';
import {IEmp} from './IEmp';
/**
 * proxy.conf.json
 * 
 * {"/api":{ "target": "http://localhost:3000", "secure": false}}
 * 
 * package.json
 * 
 * "start": "ng serve --proxy-config proxy.conf.json"
 */


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  constructor( private servicecallerservice:ServiceCallerService){
  }
  title = 'app';


   dataFromNode:any;
  

   employeeData:IEmp[]=[];

   uname:string;
   age:number;

  ngOnInit() {
    this.loaddataFromNode();
    this.getAllDbData();
  }
//data from node
  loaddataFromNode(){
    this.servicecallerservice.loaddataFromNode().subscribe(data=>this.dataFromNode=data.msg);
  }
//send data to node and db
  InvokePostRequest(){
this.servicecallerservice.postdatFromNode(this.uname,this.age).subscribe();
  }
//get all data from node
  getAllDbData(){
    this.servicecallerservice.getAllDbData().subscribe((data)=>this.employeeData=data);
  }

  //deleter from db
  
deleteDataByName(name:string){
  this.servicecallerservice.deleteDataByName(name).subscribe();
}  


  
}
