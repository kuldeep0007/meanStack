import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import {IEmp} from './app/IEmp';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' }),
};



@Injectable({
  providedIn: 'root'
})
export class ServiceCallerService {

  constructor(private http: HttpClient) { }

  ngOnInit() {
    this.loaddataFromNode();
    this.getAllDbData();
  }
  

  public url = 'http://localhost:3000/rest/api/load';

  public getdbDataUrl="http://localhost:3000/rest/api/getAlldbData"
  /** GET heroes from the server */

  loaddataFromNode(): Observable<IEmp> {
    return this.http.get<IEmp>(this.url);
  }

//send data to node and a=db
  postdatFromNode(ename:string,eage:number): Observable<IEmp>{
    console.log("Ename:"+ename);
     console.log("Eage:"+eage);
 return this.http.post('http://localhost:3000/rest/api/post',{name:ename,age:eage});
  }


//get data from node and db
 getAllDbData(): Observable<IEmp[]> {
    return this.http.get<IEmp[]>(this.getdbDataUrl);
  }

  //delete data from db
  deleteDataByName(ename:string): Observable<IEmp>{
  console.log("Ename:"+ename);
 return this.http.post('http://localhost:3000/rest/api/deleteData',{name:ename});
  }

}



